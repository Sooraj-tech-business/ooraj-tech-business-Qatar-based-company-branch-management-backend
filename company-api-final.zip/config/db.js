const mongoose = require('mongoose');

// Lambda optimization: Cache database connection
let cachedConnection = null;

const connectDB = async () => {
  // For Lambda: reuse existing connection if available
  if (cachedConnection && mongoose.connection.readyState === 1) {
    console.log('Using cached MongoDB connection');
    return cachedConnection;
  }

  try {
    // Lambda-optimized connection options
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      bufferCommands: false,
      // bufferMaxEntries: 0, // Not supported in newer MongoDB versions
      // useNewUrlParser: true, // Default in newer versions
      // useUnifiedTopology: true, // Default in newer versions
    });
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    
    // Cache the connection for Lambda
    cachedConnection = conn;
    return conn;
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    // For Lambda: don't exit process, throw error instead
    // process.exit(1);
    throw error;
  }
};

module.exports = connectDB;